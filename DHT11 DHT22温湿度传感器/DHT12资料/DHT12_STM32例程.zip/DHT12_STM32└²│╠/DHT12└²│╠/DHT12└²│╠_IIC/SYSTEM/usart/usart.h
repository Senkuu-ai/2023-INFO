#ifndef __USART_H
#define __USART_H
#include "stdio.h"	
#include "sys.h" 
#include "delay.h"



void uart_init(u32 bound); //���ڳ�ʼ��


#endif


