#ifndef __DELAY_H
#define __DELAY_H 			   
#include "sys.h"

void delay_init(void); //��ʱ��ʼ��
void delay_ms(u16 nms);	//��ʱms
extern void delay_us(u32 nus);//��ʱus

#endif





























