1.Please place the RadioHead to the arduino ide librarys
2.Restart the arduino ide and open the Transmitter and Receicer ino for test.