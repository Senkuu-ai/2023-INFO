Measure temperature and humidity with cheap DHT11 sensor and post data to thingspeak.com
==========================================================================

init.lua - set up WIFI station and wait for ip then do ds1820.lua

dht11.lua - get data from DHT11 sensor and post them to Thinkspeak.com



Please remember change your thingspeak API key and WIFI settings...
