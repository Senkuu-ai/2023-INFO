Thingspeak-Tweet
================
Example how to send tweet directly from ESP8266 with nodeMCU firmware.

The code using Thingspeak.com API to send tweet beacouse is not easy implement OAuth directly in ESP8266.

Link your twitter account in thingspeak.com and change you thingtweetAPIKey.


