Measure temperature with DS18B20 sensor and post data to thingspeak.com
==========================================================================

init.lua - set up WIFI station and wait for ip then do ds1820.lua

ds1820.lua - get data from DS18B20 sensor and post them to Thinkspeak.com


Please remember change your thingspeak API key and WIFI settings...

![Schematic](https://raw.githubusercontent.com/ok1cdj/ESP8266-LUA/master/Thermometer-DS18B20-Thingspeak/esp8266-ds18b20-2_bb.png)

