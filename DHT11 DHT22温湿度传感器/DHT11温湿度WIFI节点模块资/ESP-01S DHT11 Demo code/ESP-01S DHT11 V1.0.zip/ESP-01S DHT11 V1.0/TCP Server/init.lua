-- init.lua --
--tcp server
print("ESP8266 Server")
wifi.setmode(wifi.STATIONAP);
wifi.ap.config({ssid="test2",pwd="12345678"});
print("Server IP Address:",wifi.ap.getip())
-- Run the main file
dofile("main.lua")
