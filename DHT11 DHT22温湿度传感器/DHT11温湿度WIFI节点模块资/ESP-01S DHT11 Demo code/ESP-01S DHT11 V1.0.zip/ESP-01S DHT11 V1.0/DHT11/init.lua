--init.lua
-- tcp client
print("ESP8266 Client1")
wifi.sta.disconnect()
tmr.delay(100)
wifi.setmode(wifi.STATION) 
wifi.sta.config("test2","12345678") -- connecting to server
wifi.sta.connect() 
i=0
tmr.alarm(0,2000, 1, function() 
	if wifi.sta.getip()== nil then 
		print("IP unavaiable, Waiting...")
		i=i+1
		if(i>10) then
			print("restart nodeMCU")
			node.restart()
		end
		wifi.sta.disconnect()
		wifi.sta.connect()
	else 
		tmr.stop(0)
		print("Config done, IP is "..wifi.sta.getip())
		dofile("dht11.lua")
	end 
end)


