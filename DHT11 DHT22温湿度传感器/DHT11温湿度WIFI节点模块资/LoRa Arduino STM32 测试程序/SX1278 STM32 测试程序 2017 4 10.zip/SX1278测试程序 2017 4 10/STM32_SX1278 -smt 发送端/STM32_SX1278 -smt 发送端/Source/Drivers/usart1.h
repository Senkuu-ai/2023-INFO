
#ifndef __USART1_H__
#define __USART1_H__
#include <stdio.h>
void Uart1Init(void);


#endif

